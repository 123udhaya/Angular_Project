export const environment = {
  production: true,
  myAssetsCount: 16,
  trendingAssetsount: 16,
  mySolutionsCount: 16,
  trendingSolutionsCount: 16,
  myBookmarksCount: 10,
  recentlyPageCount: 10,
  // DevDigitalFirstApp Configuration
  // config: {
  //   tenant: 'de08c407-19b9-427d-9fe8-edf254300ca7',
  //   clientId: '17d4e26e-5589-48e9-bcbe-870740776f85',
  //   spUrl: 'https://cognizantonline.sharepoint.com/',
  //   spSiteCollection: 'sites/DevDigitalFirstApp/',
  //   redirectUri: 'http://localhost:4200/',
  //   postLogoutRedirectUri: 'http://localhost:4200/',
  //   cacheLocation: 'localStorage',
  // }

  // DigitalFirstApplication Configuration
  config: {
    tenant: 'de08c407-19b9-427d-9fe8-edf254300ca7',
    clientId: '9a4dd1b6-21f8-41ce-ba07-04184ef7ae08',
    spUrl: 'https://cognizantonline.sharepoint.com/',
    spSiteCollection: 'sites/DigitalFirstApplication/',
    redirectUri: 'https://cdodfprod.cognizant.com/DF',
    // redirectUri: 'https://bpsdboapp.cognizant.com/DF/',
    postLogoutRedirectUri: window.location.href,
    cacheLocation: 'localStorage'
  }
};
