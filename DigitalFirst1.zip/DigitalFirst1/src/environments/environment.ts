// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  myAssetsCount: 16,
  trendingAssetsount: 16,
  mySolutionsCount: 16,
  trendingSolutionsCount: 16,
  myBookmarksCount: 10,
  recentlyPageCount: 10,
  // DevDigitalFirstApp Configuration
  config: {
    tenant: 'de08c407-19b9-427d-9fe8-edf254300ca7',
    clientId: '17d4e26e-5589-48e9-bcbe-870740776f85',
    spUrl: 'https://cognizantonline.sharepoint.com/',
    spSiteCollection: 'sites/DevDigitalFirstApp/',
    redirectUri: 'http://localhost:4200/',
    postLogoutRedirectUri: window.location.href,
    cacheLocation: 'localStorage'
  }

  // DigitalFirstApplication Configuration
  // config: {
  //   tenant: 'de08c407-19b9-427d-9fe8-edf254300ca7',
  //   clientId: '9a4dd1b6-21f8-41ce-ba07-04184ef7ae08',
  //   spUrl: 'https://cognizantonline.sharepoint.com/',
  //   spSiteCollection: 'sites/DigitalFirstApplication/',
  //   redirectUri: 'https://bpsdboapp.cognizant.com/DF/',
  //   postLogoutRedirectUri: window.location.href,
  //   cacheLocation: 'localStorage',
  // }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
