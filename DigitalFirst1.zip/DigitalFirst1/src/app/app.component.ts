import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { WebService } from './services/web.service';
import { LoaderService } from './services/loader.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  loading = false;

  constructor(private titleServices: Title, private router: Router, private webService: WebService, public loaderService: LoaderService) {
    this.titleServices.setTitle('Dashboard');
  }

  ngOnInit() {
    this.loaderService.isLoading.next(true);
    this.loaderService.isLoading.subscribe(
      res => {
        this.loading = res;
      },
      error => {
        this.loading = false;
      },
      () => {
        this.loading = false;
      }
    );
  }

  get authenticate() {
    return this.webService.authenticate;
  }

  onActivate(event) {
    window.scroll(0, 0);
  }
}
