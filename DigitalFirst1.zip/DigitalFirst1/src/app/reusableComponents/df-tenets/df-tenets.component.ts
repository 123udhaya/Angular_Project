import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-df-tenets',
  templateUrl: './df-tenets.component.html',
  styleUrls: ['./df-tenets.component.css']
})
export class DfTenetsComponent implements OnInit {
  @Input() keyTenetSelected: string;
  @Input() tenetItem: Array<Object>;

  activeTab: string;
  activeChildTab: any;
  selectedTab: string;
  innerWidth: number;
  visibleItem: string;

  constructor() {}

  ngOnInit() {
    this.innerWidth = window.innerWidth;
    this.selectedTab = 'description';
  }

  /* Convert string to Object and return as Array of Object */
  parseData(value: any) {
    return [JSON.parse(value)];
  }
  /* To set the active parent tab in Human Centric Design page */
  setActiveTab(tabName) {
    this.activeTab = tabName;
    this.activeChildTab = 0;
  }

  setSelectedTab(currentTab: string) {
    this.selectedTab = currentTab;
  }

  /* Set active for choosed Accordian in mobile view */
  toggleContent(itemName: string) {
    this.visibleItem = this.visibleItem != itemName ? itemName : undefined;
  }
}
