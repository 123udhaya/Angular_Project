import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { WebService } from '../../services/web.service';
import * as _ from 'lodash';

@Component({
  selector: 'app-searchbox',
  templateUrl: './searchbox.component.html',
  styleUrls: ['./searchbox.component.css']
})
export class SearchboxComponent implements OnInit {
  serachTitleList = [];
  popuplarSearchList: Array<Object>;
  // showNoContent = false;
  filteredData: Array<string>;
  searchKey: string;
  advSearch = new FormGroup({
    searchString: new FormControl('', [Validators.required, Validators.minLength(4)]),
    searchKey: new FormControl('', [Validators.required, Validators.minLength(4)])
  });

  constructor(private webService: WebService, private route: Router, private activeRoute: ActivatedRoute) {}

  ngOnInit() {
    this.getAutoCompleteData();
    this.popuplarSearchTerm();
    this.searchKey = this.activeRoute.snapshot.queryParamMap.get('t');
  }

  searchTerm(searchText) {
    this.filteredData = [];
    if (searchText == '' || searchText == undefined) {
      // this.showNoContent = false;
      return;
    }
    this.filteredData = _.filter(this.serachTitleList, function(o) {
      return _.includes(o.toLowerCase(), searchText.toLowerCase());
    });
    // this.showNoContent = this.filteredData.length > 0 ? false : true;
  }

  /* Get search text from form */
  searchForm(text: any) {
    if (text.searchString.length <= 3) {
      return;
    }
    this.searchFromSP(text.searchString);
  }

  /* Update Search text in Sharepoint List and run search query IF exists*/
  searchFromSP(searchText) {
    if (searchText != null && (searchText.searchString != '' || searchText.searchKey != '')) {
      this.searchKey = searchText;
      searchText = typeof searchText == 'object' ? searchText.searchString : searchText;
      if (searchText.length < 2) {
        this.searchKey = '';
        return;
      }
      this.route.navigateByUrl('/search?t=' + searchText);
    } else {
      return;
    }
  }

  /* To get the Auto Complete List for Advanced Search field */
  getAutoCompleteData() {
    const autoCompleteQuery = '?$select=Title';
    this.webService.getdata('searchList', autoCompleteQuery).subscribe(data => {
      if (data['value'] && data['value'].length > 0) {
        _.forEach(data['value'], val => {
          this.serachTitleList.push(val.Title);
        });
      }
    });
  }

  /* Returns popular search term */
  popuplarSearchTerm() {
    this.popuplarSearchList = [];
    const query = '?$orderby=count desc&$top=3';
    this.webService.getdata('searchList', query).subscribe(data => {
      this.popuplarSearchList = data['value'];
    });
  }

  selectItem(event) {
    if (event.keyCode == 40) {
      document.getElementById('search').focus();
    }
  }

  addFocusElement(event) {
    if ((event.keyCode != undefined && event.keyCode == '40') || event.keyCode == '38') {
      document.getElementById('listData').classList.add('block');
      document.getElementById('filterData').focus();
    }
  }
  removeFocusElement() {
    if (document.getElementById('listData') != null) {
      document.getElementById('listData').classList.remove('block');
    }
  }
}
