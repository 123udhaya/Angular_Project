import { Component, OnInit, Input, HostListener, Directive } from '@angular/core';
import { WebService } from '../../services/web.service';
import { Router, ActivatedRoute } from '@angular/router';
import { environment } from '../../../environments/environment';
import * as _ from 'lodash';

@Component({
  selector: 'app-terms-conditionsmodal',
  templateUrl: './terms-conditionsmodal.component.html',
  styleUrls: ['./terms-conditionsmodal.component.css']
})
export class TermsConditionsmodalComponent implements OnInit {
  @Input() downloadURL: string;
  @Input() currentPageName: string;
  @Input() serviceName: string;
  @Input() downloadItemName: string;
  @Input() assetName: string;
  marked = false;
  warningMsg: Array<Object>;
  type: string;

  constructor(private route: Router, private webService: WebService) {}

  ngOnInit() {
    const listName = 'ContentLibrary';
    const queryParam = '?$filter=Title eq \'download-warning-message\'';
    this.webService.getdata(listName, queryParam).subscribe(data => {
      if (data['value'].length > 0) {
        this.warningMsg = data['value'];
      }
    });
  }

  downloadDocument(url) {
    window.open(url, '_self');
    // const listName = 'UserBasedContent';
    // const queryParam = '?$filter=UserId eq \'' + this.webService.getUserName + '\'';
    // this.webService.getdata(listName, queryParam).subscribe(data => {
    //   if (data['value'].length > 0) {
    //     const itemId = data['value'][0]['ID'];
    //     const myList =
    //       JSON.parse(data['value'][0]['documentDownloaded']) == null
    //         ? []
    //         : _.orderBy(JSON.parse(data['value'][0]['documentDownloaded']), ['count'], 'desc');
    //     const filteredList = _.filter(myList, ['pageName', this.currentPageName]);
    //     if (filteredList.length > 0) {
    //       _.forEach(myList, (v, k) => {
    //         if (v.pageName == this.currentPageName) {
    //           v.count = v.count + 1;
    //         }
    //       });
    //     } else {
    //       const index = myList.length >= environment.mySolutionsCount ? environment.mySolutionsCount - 1 : myList.length;
    //       myList[index] = { pageName: this.currentPageName, count: 1, fileURL: this.downloadURL };
    //     }
    //     const body = {
    //       __metadata: { type: 'SP.Data.UserBasedContentListItem' },
    //       Title: this.webService.getUserInfo().profile.name,
    //       UserId: this.webService.getUserName,
    //       documentDownloaded: JSON.stringify(myList)
    //     };
    //     this.webService.updateSPList(listName, itemId, body).subscribe();
    //   } else {
    //     const mySolutions = [];
    //     mySolutions.push({ pageName: this.currentPageName, count: 1, fileURL: this.downloadURL });
    //     const body = {
    //       __metadata: { type: 'SP.Data.UserBasedContentListItem' },
    //       Title: this.webService.getUserInfo().profile.name,
    //       UserId: this.webService.getUserName,
    //       documentDownloaded: JSON.stringify(mySolutions)
    //     };
    //     this.webService.postDataToSP(listName, body).subscribe(result => {});
    //   }
    // });

    /*Increasing download count for Bot Resumes*/
    if (this.assetName != null && this.assetName != undefined && this.assetName != '') {
      this.type = 'Asset';
    } else if (this.serviceName != undefined && this.downloadItemName != undefined) {
      this.type = 'Solution';
    }

    /*Increasing download count for all Service line Tenets(Ex: ProcessReimagine, SAM ...etc)*/
    if (this.serviceName != undefined && this.downloadItemName != undefined) {
      const queryParam =
        '?$filter=Title eq \'' + this.downloadItemName + '\' and serviceName eq \'' + encodeURIComponent(this.serviceName) + '\'';
      this.webService.getdata('DownloadDetails', queryParam).subscribe(data => {
        let itemId = 0;
        let count = 0;
        const service = this.serviceName;
        const item = this.downloadItemName;
        if (data['value'].length > 0) {
          _.forEach(data['value'], function(val, key) {
            if (val.Title == item && val.serviceName == service) {
              itemId = val['ID'];
              count = val.downloadCount + 1;
            }
          });
          const body = {
            __metadata: { type: 'SP.Data.DownloadDetailsListItem' },
            downloadCount: count
          };
          this.webService.updateSPList('DownloadDetails', itemId, body).subscribe();
        } else {
          const body = {
            __metadata: { type: 'SP.Data.DownloadDetailsListItem' },
            Title: this.downloadItemName,
            serviceName: this.serviceName,
            documentURL: this.downloadURL,
            documentType: this.type,
            downloadCount: 1
          };
          this.webService.postDataToSP('DownloadDetails', body).subscribe();
        }
      });
    }
  }

  // updateAssetDownloadCount(name: string) {
  //   const listName = 'DetailPage';
  //   const queryParam = '?$filter=Title eq \'' + name + '\'';
  //   this.webService.getdata(listName, queryParam).subscribe(data => {
  //     if (data['value'].length > 0) {
  //       const itemId = data['value'][0]['ID'];
  //       const downloadCount = data['value'][0].assetDownloadCount + 1;
  //       const body = {
  //         __metadata: { type: 'SP.Data.DetailPageListItem' },
  //         assetDownloadCount: downloadCount
  //       };
  //       this.webService.updateSPList(listName, itemId, body).subscribe();
  //     }
  //   });
  // }

  toggleVisibility(e) {
    if (e == 'triggerPopUp') {
      this.marked = false;
    } else {
      this.marked = e.target.checked;
    }
  }
}

/* Popup modal */
@Directive({
  selector: '[appCustomModal]'
})
export class DFDownloadModalDirective {
  constructor() {}
  @HostListener('click') modalOpen() {
    document.getElementById('downloadModal').classList.toggle('d-block');
  }
}
