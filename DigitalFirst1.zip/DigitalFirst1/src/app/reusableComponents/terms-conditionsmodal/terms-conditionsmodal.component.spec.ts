import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TermsConditionsmodalComponent } from './terms-conditionsmodal.component';

describe('TermsConditionsmodalComponent', () => {
  let component: TermsConditionsmodalComponent;
  let fixture: ComponentFixture<TermsConditionsmodalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TermsConditionsmodalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TermsConditionsmodalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
