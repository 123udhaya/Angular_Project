import { Component, OnInit, Input } from '@angular/core';
import { environment } from '../../../environments/environment';
import { WebService } from '../../services/web.service';
import * as _ from 'lodash';
import { Router } from '@angular/router';

@Component({
  selector: 'app-downloadable',
  templateUrl: './downloadable.component.html',
  styleUrls: ['./downloadable.component.css']
})
export class DownloadableComponent implements OnInit {
  @Input() downloadableContent: Array<Object>;

  innerWidth: number;
  successAlertMsg: boolean;
  limitError: boolean;
  characterLength: number;
  baseUrl = environment.config.spUrl + environment.config.spSiteCollection;
  selectedMainCategory: string;
  feedbackContent: string;
  TemplatesRadio: any;
  feedbackDesc = 'Please let us know what you are looking for, it will help us serve you better in future.';
  constructor(private webService: WebService, private route: Router) {}

  ngOnInit() {
    const urlQueryString = this.route.url.split('/');
    this.successAlertMsg = false;
    if (urlQueryString[4] != undefined) {
      this.innerWidth = window.innerWidth;
      this.selectedMainCategory = _.startCase(urlQueryString[4]);
    } else if (urlQueryString[3] != undefined) {
      this.selectedMainCategory = _.startCase(urlQueryString[3]);
    } else {
      this.selectedMainCategory = _.startCase(urlQueryString[2]);
    }
  }

  saveFeedback() {
    this.limitError = false;
    if (this.feedbackContent != null && this.feedbackContent != '' && this.feedbackContent.length >= 15) {
      const body = {
        __metadata: { type: 'SP.Data.UserFeedbackListItem' },
        Title: this.selectedMainCategory,
        UserName: this.webService.getUserInfo().profile.name,
        UserId: this.webService.getUserName,
        Feedback: this.feedbackContent,
        PageUrl: environment.config.redirectUri + _.trimStart(this.route.url, '/')
      };
      this.webService.postDataToSP('UserFeedback', body).subscribe(
        result => {},
        error => {
          console.log('error');
        },
        () => {
          // console.log('task completed');
          this.successAlertMsg = true;
          this.feedbackContent = null;
          this.characterLength = 0;
        }
      );
    } else {
      this.limitError = true;
    }
  }

  /* Download documents from KnowHub / Sharepoint */
  downloadDocument(data) {
    if (data != '') {
      /* If the download link points to KnowHub */
      if (data.includes('knowhub')) {
        window.open(data, '_self');
      } else {
        /* If the download link points to Sharepoint */
        window.open(this.baseUrl + data);
      }
    }
  }
}
