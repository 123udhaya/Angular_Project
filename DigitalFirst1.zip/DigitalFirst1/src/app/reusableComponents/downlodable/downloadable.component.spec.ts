import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DownloadableComponent } from './downloadable.component';

describe('DownloadableComponent', () => {
  let component: DownloadableComponent;
  let fixture: ComponentFixture<DownloadableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [DownloadableComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DownloadableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
