import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OrderToCashComponent } from './order-to-cash.component';

describe('OrderToCashComponent', () => {
  let component: OrderToCashComponent;
  let fixture: ComponentFixture<OrderToCashComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrderToCashComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrderToCashComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
