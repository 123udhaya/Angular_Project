import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DigitalfinanceComponent } from './digitalfinance.component';

describe('DigitalfinanceComponent', () => {
  let component: DigitalfinanceComponent;
  let fixture: ComponentFixture<DigitalfinanceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DigitalfinanceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DigitalfinanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
