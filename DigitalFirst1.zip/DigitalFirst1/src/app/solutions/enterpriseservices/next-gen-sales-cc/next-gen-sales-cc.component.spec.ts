import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NextGenSalesCCComponent } from './next-gen-sales-cc.component';

describe('NextGenSalesCCComponent', () => {
  let component: NextGenSalesCCComponent;
  let fixture: ComponentFixture<NextGenSalesCCComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NextGenSalesCCComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NextGenSalesCCComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
