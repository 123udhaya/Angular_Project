import { Component, OnInit, ViewEncapsulation, HostListener, ChangeDetectorRef, AfterContentChecked, Directive } from '@angular/core';
import { trigger, style, transition, animate } from '@angular/animations';
import { Router, ActivatedRoute } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { WebService } from '../../../services/web.service';
import { SharedService } from '../../../services/shared.service';
import { environment } from '../../../../environments/environment';
import * as _ from 'lodash';

@Component({
  selector: 'app-hcpayerops',
  templateUrl: './hcpayerops.component.html',
  styleUrls: ['./hcpayerops.component.css'],
  encapsulation: ViewEncapsulation.None,
  animations: [
    trigger('enterAnimation', [
      transition(':enter', [style({ opacity: 0 }), animate('500ms', style({ opacity: 1 }))]),
      transition(':leave', [style({ opacity: 1 }), animate('500ms', style({ opacity: 0 }))])
    ])
  ]
})
export class HcpayeropsComponent implements OnInit, AfterContentChecked {
  /* Filter options present in ProcessReimagine & SAM page*/
  filterArray = {
    processReimagine: [
      { name: 'All', selected: true, value: 'All' },
      { name: 'Tool', selected: false, value: 'Tools' },
      { name: 'Analytic', selected: false, value: 'Analytics' },
      { name: 'Human', selected: false, value: 'Human Expertise' },
      { name: 'Partner', selected: false, value: 'Partner Solutions' }
    ],
    smartAnalytics: [
      { name: 'All', selected: true, value: 'All' },
      { name: 'Analytics', selected: false, value: 'Analytics' },
      { name: 'RPA', selected: false, value: 'Intelligent Automation' },
      { name: 'Cognizant', selected: false, value: 'Cognizant Asset' },
      { name: 'Client', selected: false, value: 'Client Asset' },
      { name: '3rdParty', selected: false, value: '3rd Party Asset' }
    ],
    intelligentAutomation: [
      { name: 'All', selected: true, value: 'All' },
      { name: 'Analytics', selected: false, value: 'Analytics' },
      { name: 'RPA', selected: false, value: 'Intelligent Automation' },
      { name: 'Cognizant', selected: false, value: 'Cognizant Asset' },
      { name: 'Client', selected: false, value: 'Client Asset' },
      { name: '3rdParty', selected: false, value: '3rd Party Asset' }
    ]
  };

  tenetItem: Array<Object>;
  keyTenetSelected = 'key-tenets';
  /* Used in Digital Ready Talent Tab1 */
  mainTabHeadings = [];
  selectedMainCategory: string;
  /* SAM page table header columns */
  defaultSmartColumnName = [
    { columnName: 'column1', noContent: true },
    { columnName: 'column2', noContent: true },
    { columnName: 'column3', noContent: true },
    { columnName: 'column4', noContent: true },
    { columnName: 'column5', noContent: true },
    { columnName: 'column6', noContent: true },
    { columnName: 'column7', noContent: true },
    { columnName: 'column8', noContent: true },
    { columnName: 'column9', noContent: true },
    { columnName: 'column10', noContent: true },
    { columnName: 'column11', noContent: true },
    { columnName: 'column12', noContent: true }
  ];
  smartColumnName = [];
  filterItem: string;
  smartAnalyticsContent = [];
  listItems: Array<Object>;
  visibleItem: string;
  innerWidth: number;
  makeDefaultPage = false;
  itemId: string;
  activeTab = 'firstTab';
  isAccordionActive: false;
  checkboxDisabled = false;
  baseUrl = environment.config.spUrl + environment.config.spSiteCollection;
  parentPageName: string;
  currentPageName: string;
  samHeaderColumnCount: number; // To count the no of headers in SAM/Intell table
  currentUrl: string;
  humancentricListItems = [];
  activeChildTab: any;
  currentActiveTab: string;
  selectedTab: string;
  contentLibraryListName: string;
  samListName: string;
  tabName: string;
  hcdDocDownloadLink: string;
  downloadLinks: Array<Object>;
  serviceName = '';
  currentItemName: string;
  aomList = [];

  constructor(
    private route: Router,
    private titleService: Title,
    private webService: WebService,
    private cdref: ChangeDetectorRef,
    private shareService: SharedService,
    private activeRoute: ActivatedRoute
  ) {}

  ngOnInit() {
    this.currentUrl = this.route.url;
    const urlQueryString = this.route.url.split('/');
    this.tabName = this.activeRoute.snapshot.queryParamMap.get('tab');
    if (urlQueryString[5] != undefined) {
      this.innerWidth = window.innerWidth;
      this.show(urlQueryString[5].split('?')[0]);
      this.selectedMainCategory = _.startCase(urlQueryString[5].split('?')[0]);
      this.titleService.setTitle(this.selectedMainCategory);
      this.parentPageName = urlQueryString[4];
      this.currentPageName = urlQueryString[5].split('?')[0];

      switch (this.parentPageName) {
        case 'claims-processing':
          this.contentLibraryListName = 'HCPayer_CP_ContentLibrary';
          this.samListName = 'HCPayer_CP_SAM';
          this.serviceName = 'HC-ClaimsProcessing';
          this.aomList = ['CP-AgileOperatingModelMain', 'CP-AgileOperatingModelEntry'];
          this.mainTabHeadings = [{ key: 'HCP-CP', value: 'HcPayer Ops Claims Processing' }];
          break;
        case 'membership-services':
          this.contentLibraryListName = 'HCPayer_MS_ContentLibrary';
          this.samListName = 'HCPayer_MS_SAM';
          this.serviceName = 'HC-MemberServices';
          this.aomList = ['MS-AgileOperatingModelMain', 'MS-AgileOperatingModelEntry'];
          this.mainTabHeadings = [{ key: 'HCP-MS', value: 'HcPayer Ops Membership Services' }];
          break;
        case 'provider-services':
          this.contentLibraryListName = 'HCPayer_PS_ContentLibrary';
          this.samListName = 'HCPayer_PS_SAM';
          this.serviceName = 'HC-ProviderServices';
          this.aomList = ['PS-AgileOperatingModelMain', 'PS-AgileOperatingModelEntry'];
          this.mainTabHeadings = [{ key: 'HCP-PS', value: 'HcPayer Ops Provider Services' }];
          break;
        case 'clinical-services':
          this.contentLibraryListName = 'HCPayer_CS_ContentLibrary';
          this.samListName = 'HCPayer_CS_SAM';
          this.serviceName = 'HC-ClinicalServices';
          this.aomList = ['CS-AgileOperatingModelMain', 'CS-AgileOperatingModelEntry'];
          this.mainTabHeadings = [{ key: 'HCP-CS', value: 'HcPayer Ops Clinical Services' }];
          break;
      }
      // this.serviceName = _.startCase(this.parentPageName + ' ' + this.currentPageName);
    }
    this.getdataFromSP(['Key_Tenets', 'tenets_description', 'service_line_summary']);
    this.currentItemName = this.selectedMainCategory;
    switch (this.selectedMainCategory) {
      case 'Key Tenets':
        this.updateMySolutionsDetails(_.startCase(urlQueryString[5]));
        this.updateTrendingSolutionsDetails(_.startCase(urlQueryString[4]));
        break;
      case 'Process Reimagine':
        const processReimagineLists = ['p2p_process_reimagine', 'p2p_process_reimagine_desc', 'p2p_process_reimagine_subtext'];
        this.getdataFromSP(processReimagineLists);
        break;
      case 'Smart Analytics':
      case 'Intelligent Automation':
        this.samHeaderColumnCount = 0;
        const smartAnalyticsList = ['smartAnalytics_title', 'smartAnalytics_list', 'smartAnalytics_sor', 'smartAnalytics_knowledge'];
        this.getSAMDataFromSP(smartAnalyticsList);
        if (this.selectedMainCategory == 'Intelligent Automation') {
          this.filterItem = 'intelligentAutomation';
        } else {
          this.filterItem = 'smartAnalytics';
        }
        break;
      case 'Human Centric Design':
        this.humancentricListItems = ['human-centric-cjm', 'human-centric-process-halo', 'human-centric-reimagine-processMap'];
        this.activeTab = this.humancentricListItems[0];
        this.activeChildTab = 0;
        this.getdataFromSP(this.humancentricListItems);
        break;
      case 'New Age Metrics':
        this.getdataFromSP(['newAgeMetricsFooter']);
        this.getNewAgeContent();
        break;
      case 'Agile Operating Model':
        this.getAomContent(this.aomList);
        break;
      case 'Digital Ready Talent':
        this.activeTab = 'firstTab';
        const digitalTalentList = [
          'digital_ready_talent',
          'digital_ready_talent_executive',
          'digital_ready_talent_activities',
          'digital_ready_talent_current',
          'digital_ready_talent_future',
          'digital_ready_talent_career_peopleCount',
          'digital_ready_talent_career_domainTraining'
        ];
        this.getdataFromSP(digitalTalentList);
        break;
      default:
        break;
    }
    this.selectedTab = 'description';
  }

  ngAfterContentChecked() {
    this.cdref.detectChanges();
  }

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.innerWidth = event.target.innerWidth;
  }

  /* To get Process Reimagine page content from SharePoint */
  getdataFromSP(tabName: any) {
    this.tenetItem = [];
    tabName.forEach((val: any, key: any) => {
      const listname = this.contentLibraryListName;
      const queryParams = '?$filter=Title eq \'' + tabName[key] + '\'&$orderby=sort_order';
      this.webService.getdata(listname, queryParams).subscribe(data => {
        this.tenetItem[tabName[key]] = data['value'];
        if (this.tabName != null && this.selectedMainCategory == 'Human Centric Design') {
          this.initialActiveTab(this.tabName);
        }
        if (this.selectedMainCategory == 'Human Centric Design' && this.tenetItem['human-centric-cjm']) {
          this.hcdDocDownloadLink = this.tenetItem['human-centric-cjm'][0].downloadURL;
          this.currentItemName = 'CJM';
        }
        if (val == 'Key_Tenets') {
          this.downloadLinks = [];
          this.tenetItem['Key_Tenets'].forEach((val, key) => {
            if (val.downloadURL != undefined && val.downloadURL != null) {
              this.downloadLinks[val.SmallText] = val.downloadURL;
            }
          });
        }
      });
    });
  }

  /* Get data from SharePoint */
  getSAMDataFromSP(tabName) {
    this.listItems = [];
    let count = 0;
    tabName.forEach((val: any, key: any) => {
      const listname = this.samListName;
      const queryParams = '?$filter=Title eq \'' + tabName[key] + '\'&$orderby=sort_order';
      this.webService.getdata(listname, queryParams).subscribe(data => {
        this.listItems[tabName[key]] = data['value'];
        if (tabName[key] == 'smartAnalytics_title') {
          _.forEach(this.defaultSmartColumnName, function(val: any) {
            if (data['value'][0][val.columnName] != null && data['value'][0][val.columnName] != '') {
              count++;
            }
          });
          this.samHeaderColumnCount = count;
          /* Filtering no of columns based on the header items present in SP */
          this.smartColumnName = this.defaultSmartColumnName.slice(0, this.samHeaderColumnCount);
        }
      });
    });
  }

  /* Convert string to Object and return as Array of Object */
  parseData(value: any) {
    return [JSON.parse(value)];
  }

  /* To display corresponding tenets */
  show(val: any) {
    this.keyTenetSelected = val;
    this.getOnloadData();
  }

  /* check the current page has bookmarked or default page */
  getOnloadData() {
    const getDefaultPageQuery = '?$filter=UserId eq \'' + this.webService.getUserName + '\'';
    this.webService.getdata('UserBasedContent', getDefaultPageQuery).subscribe(res => {
      if (res['value'].length > 0) {
        this.itemId = res['value'][0]['ID'];
        if (res['value'][0]['DefaultPageUrl'] == this.route.url) {
          this.makeDefaultPage = true;
        }
      }
    });
  }

  /* To hide and show the content of SAM table and ProcessReimagine based on the filter */
  filterView(itemToDisplay: string, pageName: string) {
    if (itemToDisplay == null) {
      return;
    }
    return _.includes(
      _.uniq(
        _.map(this.filterArray[pageName], function(n) {
          return (itemToDisplay.toUpperCase().includes(n.name.toUpperCase()) && n.selected) || (n.name == 'All' && n.selected);
        })
      ),
      true
    );
  }

  /* To get the checked item and status of the filter item from the UI from SAM and ProcessReimagine page*/
  getCheckedItem(checkedItem: any, status: any, pageName: string) {
    const checkBox = this.filterArray[pageName];
    _.filter(checkBox, ['name', checkedItem])[0].selected = status;
    if (checkedItem == 'All' && status) {
      _.forEach(checkBox, function(value) {
        if (value.name == 'All') {
          return;
        }
        value.selected = false;
      });
      this.checkboxDisabled = true;
    } else {
      /* Checkbox Either Analytics or IA is true set all assets to be true */
      if ((checkedItem == 'RPA' || checkedItem == 'Analytics') && status) {
        checkBox[3].selected = true;
        checkBox[4].selected = true;
        checkBox[5].selected = true;
      }
      /* When checkbox Analytics and IA is false set all assets to be false */
      if (pageName != 'processReimagine') {
        if (!checkBox[1].selected && !checkBox[2].selected) {
          checkBox[3].selected = false;
          checkBox[4].selected = false;
          checkBox[5].selected = false;
        }

        if (!checkBox[1].selected && !checkBox[2].selected) {
          this.checkboxDisabled = true;
        } else {
          this.checkboxDisabled = false;
        }
      }

      /* set checkbox based on loaded page either Analytics or IA to be true when click on any asset checkbox */
      if (
        (checkedItem == 'Client' || checkedItem == '3rdParty' || checkedItem == 'Cognizant') &&
        status &&
        !checkBox[1].selected &&
        !checkBox[2].selected
      ) {
        if (this.filterItem == 'smartAnalytics') {
          checkBox[1].selected = true;
        } else {
          checkBox[2].selected = true;
        }
      }

      /* set all false when click on rest of the box */
      _.forEach(checkBox, function(value) {
        if (value.name == 'All') {
          value.selected = false;
        }
      });
      if (pageName == 'processReimagine') {
        if (
          checkBox[0].selected == false &&
          checkBox[1].selected == false &&
          checkBox[2].selected == false &&
          checkBox[3].selected == false &&
          checkBox[4].selected == false
        ) {
          checkBox[0].selected = true;
          this.checkboxDisabled = true;
        } else {
          this.checkboxDisabled = false;
        }
      }
    }
    /* to reset noContent when filter condition change works in mobile view */
    _.forEach(this.smartColumnName, val => {
      val.noContent = true;
    });
  }

  /* Set active for choosed Accordian in mobile view */
  toggleContent(itemName: string) {
    this.visibleItem = this.visibleItem != itemName ? itemName : undefined;
  }

  /* Hide No content found text in mobile view */
  hideNoContent(text) {
    _.forEach(this.smartColumnName, val => {
      if (val.columnName == text) {
        val.noContent = false;
      }
    });
    return true;
  }

  /* Redirect to respective tenets page on dropdown change mobile view */
  navigateOnChange(url) {
    this.route.navigateByUrl(url);
  }

  /* Set Defaultlanding page when checkbox clicked */
  setDefaultLandingPage() {
    let pageUrl;
    if (!this.makeDefaultPage) {
      pageUrl = this.route.url;
    } else {
      pageUrl = '';
    }
    const body = {
      __metadata: { type: 'SP.Data.UserBasedContentListItem' },
      Title: this.webService.getUserInfo().profile.name,
      UserId: this.webService.getUserName,
      DefaultPageUrl: pageUrl
    };

    if (this.itemId) {
      this.webService.updateSPList('UserBasedContent', this.itemId, body).subscribe(
        result => {},
        error => {
          console.log('error');
        },
        () => {
          this.getOnloadData();
        }
      );
    } else {
      this.webService.postDataToSP('UserBasedContent', body).subscribe(
        result => {},
        error => {
          console.log('error');
        },
        () => {
          this.getOnloadData();
        }
      );
    }
  }

  /* New Age metrics page */
  getNewAgeContent() {
    this.listItems = [];
    const listname = 'DF_NewAgeMetrics';
    const queryParams = '';
    this.webService.getdata(listname, queryParams).subscribe(data => {
      const arrayItem = [];
      Object.keys(data['value']).forEach((value, index) => {
        arrayItem.push({
          id: data['value'][index]['ID'],
          title: data['value'][index]['Title'],
          parent: data['value'][index]['parent'],
          order: data['value'][index]['sort_order'],
          cdo: data['value'][index]['CDOPerformance'],
          dom: data['value'][index]['domainPerformance'],
          expanded: false
        });
      });
      this.listItems['new-age-metrics'] = this.shareService.transformToTree(_.orderBy(arrayItem, ['order']));
    });
  }

  /* Agile Operating Model page */
  getAomContent(tabName: any) {
    this.listItems = [];
    tabName.forEach((val: any, key: any) => {
      const listname = 'DownloadableAssets';
      const queryParams = '?$filter=Title eq \'' + tabName[key] + '\'';
      this.webService.getdata(listname, queryParams).subscribe(data => {
        this.listItems[tabName[key]] = data['value'];
      });
    });
  }

  /* collapse or expand based on the click of each Icon */
  collapseBasedLevel(arr, status) {
    this.setCollapsedOrExpand([arr], false, !status);
  }

  /* Toggle collapse all or expand all on single click */
  toggleAllMetrics(status) {
    this.setCollapsedOrExpand(this.listItems['new-age-metrics'][0].children, true, status);
  }

  /* Set collapse or expand based on nestedChild for all elements */
  setCollapsedOrExpand(arr, nestedChild, status) {
    _.forEach(arr, v => {
      v.expanded = status;
      if (v.children.length > 0 && nestedChild) {
        this.setCollapsedOrExpand(v.children, '', status);
      }
    });
  }

  /* Download report in asset catalogue page */
  downloadDocument(data) {
    if (data != '') {
      window.open(this.baseUrl + data);
    }
  }

  /* To update Dashboard page MySolutions section based assets opened */
  updateMySolutionsDetails(name: string) {
    const listName = 'UserBasedContent';
    const queryParam = '?$filter=UserId eq \'' + this.webService.getUserName + '\'';
    this.webService.getdata(listName, queryParam).subscribe(data => {
      if (data['value'].length > 0) {
        const itemId = data['value'][0]['ID'];
        const myList =
          JSON.parse(data['value'][0]['MySolutions']) == null
            ? []
            : _.slice(_.orderBy(JSON.parse(data['value'][0]['MySolutions']), ['count'], 'desc'), 0, environment.mySolutionsCount);
        const filteredList = _.filter(myList, ['shortName', name]);
        if (filteredList.length > 0) {
          _.forEach(myList, (v, k) => {
            if (v.shortName == name) {
              v.count = v.count + 1;
            }
          });
        } else {
          const index = myList.length >= environment.mySolutionsCount ? environment.mySolutionsCount - 1 : myList.length;
          myList[index] = { shortName: name, count: 1, redirectionLink: this.route.url };
        }
        const body = {
          __metadata: { type: 'SP.Data.UserBasedContentListItem' },
          Title: this.webService.getUserInfo().profile.name,
          UserId: this.webService.getUserName,
          MySolutions: JSON.stringify(myList)
        };
        this.webService.updateSPList(listName, itemId, body).subscribe();
      } else {
        const mySolutions = [];
        mySolutions.push({ shortName: name, count: 1, redirectionLink: this.route.url });
        const body = {
          __metadata: { type: 'SP.Data.UserBasedContentListItem' },
          Title: this.webService.getUserInfo().profile.name,
          UserId: this.webService.getUserName,
          MySolutions: JSON.stringify(mySolutions)
        };
        this.webService.postDataToSP(listName, body).subscribe(
          result => {},
          error => {
            console.log('error');
          },
          () => {
            this.getOnloadData();
          }
        );
      }
    });
  }

  updateTrendingSolutionsDetails(name) {
    const listName = 'ContentLibrary';
    const queryParam = '?$filter=Title eq \'trending_solutions_dashboard\'';
    this.webService.getdata(listName, queryParam).subscribe(data => {
      if (data['value'].length > 0) {
        const itemId = data['value'][0]['ID'];
        if (data['value'][0]['trendingData'] != null && data['value'][0]['trendingData'] != '') {
          const myList =
            JSON.parse(data['value'][0]['trendingData']) == null
              ? []
              : _.slice(_.orderBy(JSON.parse(data['value'][0]['trendingData']), ['count'], 'desc'), 0, environment.trendingSolutionsCount);
          const filteredList = _.filter(myList, ['shortName', name]);
          if (filteredList.length > 0) {
            _.forEach(myList, (v, k) => {
              if (v.shortName == name) {
                v.count = v.count + 1;
              }
            });
          } else {
            const index = myList.length >= environment.trendingSolutionsCount ? environment.trendingSolutionsCount - 1 : myList.length;
            myList[index] = { shortName: name, count: 1, redirectionLink: this.route.url };
          }
          const body = {
            __metadata: { type: 'SP.Data.ContentLibraryListItem' },
            trendingData: JSON.stringify(myList)
          };
          this.webService.updateSPList(listName, itemId, body).subscribe();
        } else {
          const trendingList = [];
          trendingList.push({ shortName: name, count: 1, redirectionLink: this.route.url });
          const body = {
            __metadata: { type: 'SP.Data.ContentLibraryListItem' },
            trendingData: JSON.stringify(trendingList)
          };
          this.webService.updateSPList(listName, itemId, body).subscribe();
        }
      }
    });
  }

  @HostListener('window:scroll', ['$event'])
  onWindowScroll(e) {
    if (this.selectedMainCategory == 'Human Centric Design') {
      const horizontal = document.getElementById('tabsContainer');

      if (innerWidth <= 767) {
        if (window.pageYOffset > 180) {
          horizontal.classList.add('stickyHorizontalNav');
        } else {
          horizontal.classList.remove('stickyHorizontalNav');
        }
      } else {
        if (window.pageYOffset > 185) {
          horizontal.classList.add('stickyHorizontalNav');
        } else {
          horizontal.classList.remove('stickyHorizontalNav');
        }
      }
    }

    if (this.currentActiveTab == 'Process Halo' && innerWidth > 991) {
      const verticalNavBar = document.getElementById('humanCentric-sideNavBar--container');
      if (window.pageYOffset > 185) {
        verticalNavBar.classList.add('sticky');
      } else {
        verticalNavBar.classList.remove('sticky');
      }
    }
  }

  /* Scroll to particular Hash on click */
  scrollTo(section: any) {
    let topOffset = 130;
    if (this.innerWidth < 1200) {
      topOffset = 70;
    }
    const selectedDiv: any = document.querySelector('#' + section);
    window.scrollTo(0, selectedDiv.offsetTop + topOffset);
  }

  /* Remove special characters and convert the text to upper case */
  textFormatter(text: string) {
    return _.upperCase(text);
  }

  /* Converts tje first character of the string to upper case */
  startCaseFormat(text: string) {
    return _.startCase(text);
  }

  /* To set the active parent tab in Human Centric Design page */
  setActiveTab(tabName) {
    this.activeTab = tabName;
    this.activeChildTab = 0;
    switch (tabName) {
      case 'human-centric-cjm':
        this.hcdDocDownloadLink = this.tenetItem['human-centric-cjm'][0].downloadURL;
        this.currentItemName = 'CJM';
        break;
      case 'human-centric-process-halo':
        this.hcdDocDownloadLink = this.tenetItem['human-centric-process-halo'][0].downloadURL;
        this.currentItemName = 'Process Halo';
        break;
      case 'human-centric-reimagine-processMap':
        this.hcdDocDownloadLink = this.tenetItem['human-centric-reimagine-processMap'][0].downloadURL;
        this.currentItemName = 'Reimagine Process Map';
        break;
    }
  }

  initialActiveTab(name) {
    this.activeChildTab = 0;
    switch (name) {
      case 'Customer Journey Maps':
        this.activeTab = this.humancentricListItems[0];
        this.hcdDocDownloadLink = this.tenetItem[this.humancentricListItems[0]][0].downloadURL;
        if (this.tenetItem[this.humancentricListItems[0]]) {
          if (this.tenetItem[this.humancentricListItems[0]]) {
            this.currentActiveTab = this.tenetItem[this.humancentricListItems[0]][0]['SmallText'];
          }
        }
        break;
      case 'Process Halo':
        this.activeTab = this.humancentricListItems[1];
        this.hcdDocDownloadLink = this.tenetItem[this.humancentricListItems[1]][0].downloadURL;
        if (this.tenetItem[this.humancentricListItems[1]]) {
          this.currentActiveTab = this.tenetItem[this.humancentricListItems[1]][0]['SmallText'];
        }
        break;

      default:
        this.activeTab = name;
        break;
    }
  }

  customNavigation(pageURL, menuName) {
    this.shareService.customNavigation(pageURL, menuName);
  }

  setSelectedTab(currentTab: string) {
    this.selectedTab = currentTab;
  }
}
