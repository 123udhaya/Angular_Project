import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManufacturingopsComponent } from './manufacturingops.component';

describe('ManufacturingopsComponent', () => {
  let component: ManufacturingopsComponent;
  let fixture: ComponentFixture<ManufacturingopsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManufacturingopsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManufacturingopsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
