import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OperationalanalyticsComponent } from './operationalanalytics.component';

describe('OperationalanalyticsComponent', () => {
  let component: OperationalanalyticsComponent;
  let fixture: ComponentFixture<OperationalanalyticsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OperationalanalyticsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OperationalanalyticsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
