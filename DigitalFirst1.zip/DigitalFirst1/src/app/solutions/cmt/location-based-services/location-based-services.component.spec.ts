import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LocationBasedServicesComponent } from './location-based-services.component';

describe('MapsAgileInnovationComponent', () => {
  let component: LocationBasedServicesComponent;
  let fixture: ComponentFixture<LocationBasedServicesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [LocationBasedServicesComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LocationBasedServicesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
