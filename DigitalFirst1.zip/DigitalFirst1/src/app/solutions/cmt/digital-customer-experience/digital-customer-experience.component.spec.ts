import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DigitalCustomerExperienceComponent } from './digital-customer-experience.component';

describe('DigitalCustomerExperienceComponent', () => {
  let component: DigitalCustomerExperienceComponent;
  let fixture: ComponentFixture<DigitalCustomerExperienceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DigitalCustomerExperienceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DigitalCustomerExperienceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
