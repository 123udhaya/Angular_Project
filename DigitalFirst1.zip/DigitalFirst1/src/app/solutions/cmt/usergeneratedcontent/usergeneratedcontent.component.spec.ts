import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UsergeneratedcontentComponent } from './usergeneratedcontent.component';

describe('UsergeneratedcontentComponent', () => {
  let component: UsergeneratedcontentComponent;
  let fixture: ComponentFixture<UsergeneratedcontentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UsergeneratedcontentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UsergeneratedcontentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
