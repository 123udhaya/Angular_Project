import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MortgageoperationsComponent } from './mortgageoperations.component';

describe('MortgageoperationsComponent', () => {
  let component: MortgageoperationsComponent;
  let fixture: ComponentFixture<MortgageoperationsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MortgageoperationsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MortgageoperationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
