import { Component, OnInit, HostListener } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { WebService } from '../services/web.service';
import { SharedService } from '../services/shared.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-aboutdf',
  templateUrl: './aboutdf.component.html',
  styleUrls: ['./aboutdf.component.css']
})
export class AboutdfComponent implements OnInit {
  showPlus: number;
  aboutPageContent: Array<Object>;
  currentSection: string;
  aboutPageLists = [
    'aboutdf',
    'Key_Tenets',
    'dfGoals',
    'DF_Execution_Execute',
    'DF_Execution_build_sell',
    'DF_Execution_manage_client',
    'DF_Faq',
    'Amplify_DF_Synergy',
    'amplifyOfferings_industry_platform_solutions',
    'amplifyOfferings_enterprise_services',
    'amplifyOfferings_intelligent_process_automation'
  ];
  innerWidth: any;
  visibleItem: string;

  constructor(private titleService: Title, private webService: WebService, private route: Router, private shareService: SharedService) {}

  ngOnInit() {
    this.titleService.setTitle('About DO');
    this.currentSection = 'amplify_offerings'; // Active Side Tab
    this.callSPOnlineList(this.aboutPageLists);
    this.innerWidth = window.innerWidth;
  }

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.innerWidth = event.target.innerWidth;
  }

  /* SharePoint Request */
  callSPOnlineList(tabName: any) {
    this.aboutPageContent = [];
    tabName.forEach((val, key) => {
      const listname = 'ContentLibrary';
      const queryParams = '?$filter=Title eq \'' + tabName[key] + '\'&$orderby=sort_order';
      this.webService.getdata(listname, queryParams).subscribe(data => {
        this.aboutPageContent[tabName[key]] = data['value'];
      });
    });
  }

  /* Convert string to Object and return as Array of Object */
  parseData(value: any) {
    return JSON.parse(value);
  }

  /* Set Active section on scroll*/
  // onSectionChange(sectionId: string) {
  //   this.currentSection = sectionId;
  // }

  /* Scroll to particular Hash on click */
  // scrollTo(section: any) {
  //   let topOffset = 0;
  //   if (this.innerWidth < 1200) {
  //     topOffset = 70;
  //   }
  //   const selectedDiv: any = document.querySelector('#' + section);
  //   window.scrollTo(0, selectedDiv.offsetTop - topOffset);
  // }

  /* Toggle for Faq */
  toggle(event: any) {
    this.showPlus = this.showPlus == event ? undefined : event;
  }

  /* Set active for choosed Accordian in mobile view */
  toggleAccordianContent(itemName: string) {
    this.visibleItem = this.visibleItem != itemName ? itemName : undefined;
  }

  setActiveSection(sectionName: string) {
    this.currentSection = sectionName;
    this.shareService.scrollToTop();
  }

  @HostListener('window:scroll', ['$event'])
  onWindowScroll(e) {
    const verticalNavBar = document.getElementById('scroll-sidenav-bar');
    if (innerWidth <= 767) {
      if (window.pageYOffset > 180) {
        verticalNavBar.classList.add('stickySideNavBar');
      } else {
        verticalNavBar.classList.remove('stickySideNavBar');
      }
    } else {
      if (window.pageYOffset > 0) {
        verticalNavBar.classList.add('stickySideNavBar');
      } else {
        verticalNavBar.classList.remove('stickySideNavBar');
      }
    }
  }
}
