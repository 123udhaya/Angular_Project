import { Component, OnInit, HostListener } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { WebService } from '../../services/web.service';
import { Router } from '@angular/router';
import { environment } from '../../../environments/environment';
import * as _ from 'lodash';

@Component({
  selector: 'app-knowledge-asset',
  templateUrl: './knowledge-asset.component.html',
  styleUrls: ['./knowledge-asset.component.css']
})
export class KnowledgeAssetComponent implements OnInit {
  selectedSection: string;
  innerWidth: any;
  listItem: Array<Object>;
  makeDefaultPage = false;
  itemId: string;
  baseUrl = environment.config.spUrl + environment.config.spSiteCollection;
  selectedPage: Array<string>;
  currentPageName: string;
  parentPageName: string;

  constructor(private titleService: Title, private route: Router, private webService: WebService) {}

  ngOnInit() {
    const urlQueryString = this.route.url.split('/');
    this.selectedSection = _.startCase(urlQueryString[3]);
    this.parentPageName = urlQueryString[2];
    this.currentPageName = urlQueryString[3];
    this.getOnloadData();
    this.titleService.setTitle(this.selectedSection);
    this.innerWidth = window.innerWidth;
    switch (this.selectedSection) {
      case 'Process Flows':
        this.selectedPage = ['ProcessFlowsMain', 'ProcessFlowsEntry'];
        break;
      case 'Customer Journey Maps':
        this.selectedPage = ['CustomerJourneyMapsMain', 'CustomerJourneyMapsEntry'];
        break;
      default:
        break;
    }
    this.getdataFromSP(this.selectedPage);
  }

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.innerWidth = event.target.innerWidth;
  }

  /* To get DO Templates content from SharePoint */
  getdataFromSP(tabName: any) {
    this.listItem = [];
    tabName.forEach((val: any, key: any) => {
      const listname = 'DownloadableAssets';
      const queryParams = '?$filter=Title eq \'' + tabName[key] + '\'';
      this.webService.getdata(listname, queryParams).subscribe(data => {
        this.listItem[tabName[key]] = data['value'];
      });
    });
  }

  /* check the current page has bookmarked or default page */
  getOnloadData() {
    const getDefaultPageQuery = '?$filter=UserId eq \'' + this.webService.getUserName + '\'';
    this.webService.getdata('UserBasedContent', getDefaultPageQuery).subscribe(res => {
      if (res['value'].length > 0) {
        this.itemId = res['value'][0]['ID'];
        if (res['value'][0]['DefaultPageUrl'] == this.route.url) {
          this.makeDefaultPage = true;
        }
      }
    });
  }

  /* Download report in asset catalogue page */
  downloadDocument(data) {
    window.open(this.baseUrl + data);
  }

  /* Set Defaultlanding page when checkbox clicked */
  setDefaultLandingPage() {
    let pageUrl;
    if (!this.makeDefaultPage) {
      pageUrl = this.route.url;
    } else {
      pageUrl = '';
    }
    const body = {
      __metadata: { type: 'SP.Data.UserBasedContentListItem' },
      Title: this.webService.getUserInfo().profile.name,
      UserId: this.webService.getUserName,
      DefaultPageUrl: pageUrl
    };

    if (this.itemId) {
      this.webService.updateSPList('UserBasedContent', this.itemId, body).subscribe(
        result => {},
        error => {
          console.log('error');
        },
        () => {
          this.getOnloadData();
        }
      );
    } else {
      this.webService.postDataToSP('UserBasedContent', body).subscribe(
        result => {},
        error => {
          console.log('error');
        },
        () => {
          this.getOnloadData();
        }
      );
    }
  }
}
