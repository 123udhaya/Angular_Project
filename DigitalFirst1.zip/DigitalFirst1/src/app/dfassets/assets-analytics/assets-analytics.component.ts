import { Component, OnInit, HostListener } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { WebService } from '../../services/web.service';
import { SharedService } from '../../services/shared.service';
import { environment } from '../../../environments/environment';
import * as _ from 'lodash';

@Component({
  selector: 'app-assets-analytics',
  templateUrl: './assets-analytics.component.html',
  styleUrls: ['./assets-analytics.component.css']
})
export class AssetsAnalyticsComponent implements OnInit {
  mainTabHeadings = [
    { key: 'O2C', value: 'Order to Cash (O2C)' },
    { key: 'P2P', value: 'Procure to Pay (P2P)' },
    { key: 'R2R', value: 'Record to Report (R2R)' }
  ];
  inputColumns = [
    { columnName: 'Title', text: 'Asset Name' },
    { columnName: 'Description', text: 'Description' },
    { columnName: 'Benefits', text: 'Key Business Benefits' },
    { columnName: 'Implemented', text: 'Implemented in' },
    { columnName: 'owner_name', text: 'Asset Owner' }
  ];
  pageOptions = [5, 10, 20];
  itemsToShow = this.pageOptions[0];
  selectedMainTab = this.mainTabHeadings[1];
  pager: any = {};
  assetOptions: string;
  innerWidth: any;
  currentPageName: string;
  parentPageName: string;
  groupedAssetPageName: string;
  solutionsName: string;
  visibleItem: string;
  tableData = [];
  makeDefaultPage = false;
  itemId: string;
  filterTitle: string;
  assetsP2PContents: Object;
  pagedItems: any[];
  filteredItems: any[];
  allItemsLength: number;
  currentPageIndex: number;
  baseUrl = environment.config.spUrl + environment.config.spSiteCollection;
  sortingOrder: any;
  fitlerSearchEnabled = true;
  currentUrl: string;
  serviceName: string;

  constructor(private titleService: Title, private webService: WebService, private route: Router, private shareService: SharedService) {}

  ngOnInit() {
    this.currentUrl = this.route.url;
    const urlQueryString = this.currentUrl.split('/');
    this.getOnloadData();
    if (urlQueryString[5] != undefined && urlQueryString[5] == 'summary') {
      this.assetOptions = 'All';
      sessionStorage.setItem('assetsOptionsAnalytics', this.assetOptions);
    } else {
      this.assetOptions = sessionStorage.getItem('assetsOptionsAnalytics') ? sessionStorage.getItem('assetsOptionsAnalytics') : 'All';
    }
    if (urlQueryString[6] != undefined && urlQueryString[4] != 'all-assets') {
      this.titleService.setTitle(this.startCaseConverter(urlQueryString[6] == 'summary' ? urlQueryString[5] : urlQueryString[6]));
      this.solutionsName = urlQueryString[3];
      this.groupedAssetPageName = urlQueryString[4];
      this.parentPageName = urlQueryString[5];
      this.currentPageName = urlQueryString[6];
      this.getSummaryList();
      this.getSPData(urlQueryString[6]);
    } else if (urlQueryString[5] != undefined && urlQueryString[3] != 'all-assets') {
      this.titleService.setTitle(this.startCaseConverter(urlQueryString[5] == 'summary' ? urlQueryString[4] : urlQueryString[5]));
      this.groupedAssetPageName = urlQueryString[3];
      this.parentPageName = urlQueryString[4];
      this.currentPageName = urlQueryString[5];
      this.getSummaryList();
      this.getSPData(urlQueryString[5]);
    }
    // if (urlQueryString[5] != undefined && urlQueryString[3] != 'all-assets') {
    //   this.titleService.setTitle(this.startCaseConverter(urlQueryString[5] == 'summary' ? urlQueryString[4] : urlQueryString[5]));
    //   this.groupedAssetPageName = urlQueryString[3];
    //   this.parentPageName = urlQueryString[4];
    //   this.currentPageName = urlQueryString[5];
    //   this.getSummaryList();
    //   this.getSPData(urlQueryString[5]);
    // }
    if (urlQueryString[3] == 'all-assets') {
      this.titleService.setTitle(this.startCaseConverter(urlQueryString[4]));
      this.groupedAssetPageName = urlQueryString[3];
      this.parentPageName = urlQueryString[4];
      this.currentPageName = urlQueryString[5];
      this.getSummaryList();
    }

    this.serviceName = _.startCase(this.parentPageName);
    this.innerWidth = window.innerWidth;
  }

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.innerWidth = event.target.innerWidth;
  }

  /* Convert text's first character to caps */
  startCaseConverter(text) {
    return _.startCase(text);
  }

  /* Sort Summary list items */
  sortSummary(val: any) {
    if (val == undefined) {
      val = 'desc';
    }
    this.sortingOrder = val == 'desc' ? 'asc' : 'desc';
    this.pagedItems = _.orderBy(this.pagedItems, ['Title'], this.sortingOrder);
  }

  /* Get data from SharePoint List */
  getSPData(name: any) {
    this.assetsP2PContents = {};
    const listname = 'DetailPage';
    const queryParams = '?$filter=Title eq \'' + name + '\'';
    this.webService.getdata(listname, queryParams).subscribe(data => {
      this.assetsP2PContents = data['value'][0];
      if (name != 'summary' && this.assetsP2PContents['solutionDepends'] != 'CaseStudy') {
        this.updateMyAssetDetails(data['value'][0]['shortName']);
        this.updateTrendingAssetDetails(data['value'][0]['Title']);
      }
    });
  }

  /* check the current page has bookmarked or default page */
  getOnloadData() {
    const getDefaultPageQuery = '?$filter=UserId eq \'' + this.webService.getUserName + '\'';
    this.webService.getdata('UserBasedContent', getDefaultPageQuery).subscribe(res => {
      if (res['value'].length > 0) {
        this.itemId = res['value'][0]['ID'];
        if (res['value'][0]['DefaultPageUrl'] == this.route.url) {
          this.makeDefaultPage = true;
        }
      }
    });
  }

  /* Get data from SharePoint List to display in summary page */
  getSummaryList() {
    // this.filterTitle = '';
    // this.filterText(this.filterTitle);
    const listname = 'DetailPage';
    sessionStorage.setItem('assetsOptionsAnalytics', this.assetOptions);
    const queryOption = this.groupedAssetPageName == 'all-assets' ? '' : 'assetDepends eq \'' + this.parentPageName + '\' and ';
    let queryParams = '?$filter=' + queryOption + 'solutionDepends eq \'Analytics\'';
    if (this.assetOptions != 'All') {
      // queryParams += 'and category eq \'' + this.assetOptions + '\'';
      queryParams += 'and (substringof(\'' + this.assetOptions + '\',category))';
    }
    queryParams += '&$top=500';
    this.webService.getdata(listname, queryParams).subscribe(data => {
      this.tableData = data['value'];
      _.forEach(this.tableData, (val: any, key) => {
        if (this.currentPageName == val.Title.trim()) {
          this.currentPageIndex = key;
        }
      });
      if (this.tableData.length > 0) {
        this.allItemsLength = this.tableData.length;
        this.toggleContent(data['value'][0].Title);
      }
      this.setPage(1);
    });
  }

  /* Choose the available list in dropdown for mobile screen */
  changeAsset(redirectLink: string) {
    this.route.navigateByUrl(redirectLink);
  }

  /* Load Next or Previous asset based on Summary list */
  showNextPreviousData(text: string) {
    this.route.navigateByUrl(this.tableData[text].redirectionLink);
  }

  /* Get search text from form */
  filterText(s) {
    if (s == '') {
      this.fitlerSearchEnabled = true;
      this.setPage(this.pager.currentPage);
      return;
    }
    this.fitlerSearchEnabled = false;
    this.filteredItems = [];
    _.forEach(this.tableData, val => {
      if (_.lowerCase(val.shortName.toLowerCase()).includes(_.lowerCase(s))) {
        this.filteredItems.push(val);
      }
    });
    this.setPage(1);
  }

  /* To get the Page Items to be show based on the user selection of dropdown */
  setPage(page: number) {
    const availableData = this.fitlerSearchEnabled ? this.tableData : this.filteredItems;
    this.allItemsLength = availableData.length;
    this.pager = this.shareService.getPager(availableData.length, page, this.itemsToShow);
    this.pagedItems = availableData.slice(this.pager.startIndex, this.pager.endIndex + 1);
  }

  /* Dropdonw OnChange event to show the number of items in a page */
  selectPageChangeHandler(event: any) {
    const availableData = this.fitlerSearchEnabled ? this.tableData : this.filteredItems;
    this.pager = this.shareService.getPager(availableData.length, 1, this.itemsToShow);
    this.pagedItems = availableData.slice(this.pager.startIndex, this.pager.endIndex + 1);
  }

  /* Set active for choosed Accordian in mobile view */
  toggleContent(itemName: string) {
    this.visibleItem = this.visibleItem != itemName ? itemName : undefined;
  }

  /* Set Defaultlanding page when checkbox clicked */
  setDefaultLandingPage() {
    let pageUrl;
    if (!this.makeDefaultPage) {
      pageUrl = this.route.url;
    } else {
      pageUrl = '';
    }
    const body = {
      __metadata: { type: 'SP.Data.UserBasedContentListItem' },
      Title: this.webService.getUserInfo().profile.name,
      UserId: this.webService.getUserName,
      DefaultPageUrl: pageUrl
    };

    if (this.itemId) {
      this.webService.updateSPList('UserBasedContent', this.itemId, body).subscribe(
        result => {},
        error => {
          console.log('error');
        },
        () => {
          // console.log('task completed');
          this.getOnloadData();
        }
      );
    } else {
      this.webService.postDataToSP('UserBasedContent', body).subscribe(
        result => {},
        error => {
          console.log('error');
        },
        () => {
          // console.log('task completed');
          this.getOnloadData();
        }
      );
    }
  }

  /* Convert string to Object and return as Array of Object */
  parseData(value: any) {
    return [JSON.parse(value)];
  }

  /* To update Dashboard page MyAssets section based assets opened */
  updateMyAssetDetails(name: string) {
    const listName = 'UserBasedContent';
    const queryParam = '?$filter=UserId eq \'' + this.webService.getUserInfo().userName + '\'';
    this.webService.getdata(listName, queryParam).subscribe(data => {
      if (data['value'].length > 0) {
        const itemId = data['value'][0]['ID'];
        const myList =
          JSON.parse(data['value'][0]['MyAssets']) == null
            ? []
            : _.slice(_.orderBy(JSON.parse(data['value'][0]['MyAssets']), ['count'], 'desc'), 0, environment.myAssetsCount);
        const filteredList = _.filter(myList, ['shortName', name]);
        if (filteredList.length > 0) {
          _.forEach(myList, (v, k) => {
            if (v.shortName == name) {
              v.count = v.count + 1;
            }
          });
        } else {
          const index = myList.length >= environment.myAssetsCount ? environment.myAssetsCount - 1 : myList.length;
          myList[index] = { shortName: name, count: 1, redirectionLink: this.route.url };
        }
        const body = {
          __metadata: { type: 'SP.Data.UserBasedContentListItem' },
          Title: this.webService.getUserInfo().profile.name,
          UserId: this.webService.getUserInfo().userName,
          MyAssets: JSON.stringify(myList)
        };
        this.webService.updateSPList(listName, itemId, body).subscribe();
      } else {
        const myAssets = [];
        myAssets.push({ shortName: name, count: 1, redirectionLink: this.route.url });
        const body = {
          __metadata: { type: 'SP.Data.UserBasedContentListItem' },
          Title: this.webService.getUserInfo().profile.name,
          UserId: this.webService.getUserInfo().userName,
          MyAssets: JSON.stringify(myAssets)
        };
        this.webService.postDataToSP(listName, body).subscribe(result => {});
      }
    });
  }

  updateTrendingAssetDetails(assetName: string) {
    const listName = 'DetailPage';
    const queryParam = '?$filter=Title eq \'' + assetName + '\'';
    this.webService.getdata(listName, queryParam).subscribe(data => {
      if (data['value'].length > 0) {
        const itemId = data['value'][0]['ID'];
        const visitCount = data['value'][0].AssetVisitCount + 1;
        const body = {
          __metadata: { type: 'SP.Data.DetailPageListItem' },
          AssetVisitCount: visitCount
        };
        this.webService.updateSPList(listName, itemId, body).subscribe();
      }
    });
  }

  scrollTop() {
    this.shareService.scrollToTop();
  }

  /* Remove special characters and convert the text to upper case */
  textFormatter(text: string) {
    return _.upperCase(text);
  }
}
