import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { WebService } from '../services/web.service';
import * as _ from 'lodash';
import { environment } from '../../environments/environment';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  searchContent: any;
  searchContent1: any;
  rs: number;
  tr:any;
  tr1:any;
  popuplarSearchList: Array<any>;
  baseUrl = _.trimEnd(environment.config.redirectUri, '/');

  constructor(private activateRoute: ActivatedRoute, private webService: WebService) {}

  ngOnInit() {
    this.activateRoute.queryParams.subscribe(data => {
      this.searchDataFromSp(data.t);
    });
  }

  searchDataFromSp(searchText) {
    this.searchContent = [];
    this.searchContent1 = [];
    this.rs=0;
    this.tr;
    /* Fetching the relevent data from SP using the searchText by post request */
    const query = '_api/search/postquery';
    const searchBody = {
      request: {
        __metadata: { type: 'Microsoft.Office.Server.Search.REST.SearchRequest' },
        Querytext: searchText,
        QueryTemplate:
          '{searchterms} (Path:' + environment.config.spUrl + environment.config.spSiteCollection + ') contentclass:STS_ListItem',
        SelectProperties: {
          results: ['RefinableString08', 'HitHighlightedSummary']
        },
        RowLimit: 50,
        TrimDuplicates: false
      }
    };
    this.webService.customPostQuery(query, searchBody).subscribe(res => {
      _.forEach(res.d.postquery.PrimaryQueryResult.RelevantResults.Table.Rows.results, v => {
        const myCell = v.Cells.results;
        const description = _.filter(myCell, ['Key', 'HitHighlightedSummary'])[0].Value;
        const result = _.filter(myCell, ['Key', 'RefinableString08'])[0].Value;
        if (result == '') {
          return;
        } else {
          
        }
        this.searchContent.push({ highlightedSummary: _.startCase(description), res: JSON.parse(result) });
      });

      /* Inserting or Updating the searchText in SP for maintaining the Popular Search Terms */
      const searchFindQuery = '?$filter=Title eq \'' + searchText + '\'';
      this.webService.getdata('searchList', searchFindQuery).subscribe(data => {
        if (data['value'] && data['value'].length > 0) {
          const count = data['value'][0]['count'] + 1;
          const id = data['value'][0]['ID'];
          const searchReplaceBody = {
            __metadata: { type: 'SP.Data.SearchListListItem' },
            count: count
          };
          this.webService.updateSPList('searchList', id, searchReplaceBody).subscribe(res => {});
        } else {
          /* To check whether the searchText is valid or not, before inserting into SP*/
          if (this.searchContent.length > 0) {
            const searchReplaceBody = {
              __metadata: { type: 'SP.Data.SearchListListItem' },
              Title: searchText,
              count: 1
            };
            this.webService.postDataToSP('searchList', searchReplaceBody).subscribe(res => {});
          }
        }
      });
    });

    // this.searchContent = [];
    // const query =
    //   '_api/search/query?querytext=\'' +
    //   searchText +
    //   ' (Path:' +
    //   environment.config.spUrl +
    //   environment.config.spSiteCollection +
    //   ') (contentclass:STS_ListItem)\'&selectproperties=\'Title,RefinableString08,path\'&trimduplicates=false&RowLimit=50';

    // this.webService.customQuery(query).subscribe(data => {
    //   Object.keys(data['PrimaryQueryResult']['RelevantResults']['Table']['Rows']).forEach((v, k) => {
    //     const myCell = data['PrimaryQueryResult']['RelevantResults']['Table']['Rows'][k]['Cells'];
    //     const title = _.filter(myCell, ['Key', 'Title'])[0].Value;
    //     const result = _.filter(myCell, ['Key', 'RefinableString08'])[0].Value;
    //     if (result == '') {
    //       return;
    //     }
    //     this.searchContent.push({ title: title, res: result });
    //   });
    //   console.log(this.searchContent);
    // });
  }
}
