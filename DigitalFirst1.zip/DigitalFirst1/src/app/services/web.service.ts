import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AdalService } from 'adal-angular4';
import { environment } from '../../environments/environment';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/mergeMap';
import { map } from 'rxjs/operators';
import * as _ from 'lodash';

@Injectable()
export class WebService {
  constructor(private http: HttpClient, private adalService: AdalService) {
    this.adalService.init(environment.config);
  }
  RecentlyVisitedPageList = [];
  isBookmarked = false;
  bookmarkAlertMsg = false;
  bookmarkLimit = environment.myBookmarksCount;

  login() {
    return this.adalService.login();
  }

  logout() {
    localStorage.removeItem('guestUserProfilesList');
    this.adalService.logOut();
  }

  handleWindowCallback() {
    this.adalService.handleWindowCallback();
  }

  getUser() {
    return this.adalService.getUser();
  }

  getUserInfo() {
    return this.adalService.userInfo;
  }

  get authenticate() {
    return this.adalService.userInfo.authenticated;
  }

  get getCachedToken() {
    return this.adalService.getCachedToken(environment.config.spUrl);
  }

  get getUserName() {
    return this.adalService.userInfo.userName;
  }

  /**
   * Returns data to subscribe
   * @param listname String
   * @param queryParams String
   */
  getdata(listname, queryParams): Observable<any> {
    const url =
      // tslint:disable-next-line: max-line-length
      environment.config.spUrl + environment.config.spSiteCollection + '_api/web/lists/getByTitle(\'' + listname + '\')/items' + queryParams;
    try {
      return this.adalService.acquireToken(environment.config.spUrl).flatMap(token => {
        const headersParam = new HttpHeaders({
          'Content-Type': 'application/json;odata=verbose',
          'X-Content-Type-Options': 'nosniff',
          Authorization: 'Bearer ' + token.toString()
        });
        return this.http.get(url, { headers: headersParam }).toPromise();
      });
    } catch (error) {
      console.log('Error Message ', error);
    }
  }

  /**
   * Custom Query can send for different cases
   * @param query string
   */
  customQuery(query): Observable<any> {
    const url = environment.config.spUrl + environment.config.spSiteCollection + query;
    try {
      return this.adalService.acquireToken(environment.config.spUrl).flatMap(token => {
        const headersParam = new HttpHeaders({
          'Content-Type': 'application/json;odata=verbose',
          'X-Content-Type-Options': 'nosniff',
          Authorization: 'Bearer ' + token.toString()
        });
        return this.http.get(url, { headers: headersParam });
      });
    } catch (error) {
      console.log('Error Message ', error);
    }
  }

  /* Send post request with custom query */
  customPostQuery(query, queryParams): Observable<any> {
    const url = environment.config.spUrl + environment.config.spSiteCollection + query;
    try {
      return this.adalService.acquireToken(environment.config.spUrl).flatMap(token => {
        const headersParam = new HttpHeaders({
          Authorization: 'Bearer ' + token.toString(),
          'Content-Type': 'application/json;odata=verbose',
          'X-Content-Type-Options': 'nosniff',
          Accept: 'application/json;odata=verbose'
        });
        return this.http.post(url, JSON.stringify(queryParams), { headers: headersParam }).toPromise();
      });
    } catch (error) {
      console.log('Error Message ', error);
    }
  }

  /* Create new list item */
  postDataToSP(listname, queryParams) {
    const url = environment.config.spUrl + environment.config.spSiteCollection + '_api/web/lists/getByTitle(\'' + listname + '\')/items';
    try {
      return this.adalService.acquireToken(environment.config.spUrl).flatMap(token => {
        const headersParam = new HttpHeaders({
          Authorization: 'Bearer ' + token.toString(),
          'Content-Type': 'application/json;odata=verbose',
          'X-Content-Type-Options': 'nosniff',
          Accept: 'application/json;odata=verbose'
        });
        return this.http.post(url, JSON.stringify(queryParams), { headers: headersParam }).toPromise();
      });
    } catch (error) {
      console.log('Error Message ', error);
    }
  }

  /* Editing the list item */
  updateSPList(listname, id, queryParams) {
    const url =
      environment.config.spUrl + environment.config.spSiteCollection + '_api/web/lists/getByTitle(\'' + listname + '\')/items(' + id + ')';
    try {
      return this.adalService.acquireToken(environment.config.spUrl).flatMap(token => {
        const headersParam = new HttpHeaders({
          Authorization: 'Bearer ' + token.toString(),
          'Content-Type': 'application/json;odata=verbose',
          Accept: 'application/json;odata=verbose',
          'X-Content-Type-Options': 'nosniff',
          'IF-MATCH': '*',
          'X-HTTP-Method': 'MERGE'
        });
        return this.http.post(url, JSON.stringify(queryParams), { headers: headersParam }).toPromise();
      });
    } catch (error) {
      console.log('Error Message ', error);
    }
  }

  saveRecentlyVisitedPageDetails(pageName, pageUrl) {
    let body;
    const queryParam = '?$filter=UserId eq \'' + this.getUserName + '\'';
    const url =
      environment.config.spUrl + environment.config.spSiteCollection + '_api/web/lists/getByTitle(\'UserBasedContent\')/items' + queryParam;
    try {
      return this.adalService.acquireToken(environment.config.spUrl).flatMap(token => {
        const headersParam = new HttpHeaders({
          'Content-Type': 'application/json;odata=verbose',
          'X-Content-Type-Options': 'nosniff',
          Authorization: 'Bearer ' + token.toString()
        });
        return this.http.get(url, { headers: headersParam }).pipe(
          map(data => {
            if (data['value'].length > 0) {
              const userId = data['value'][0]['ID'];
              const resultData =
                JSON.parse(data['value'][0]['RecentlyVisitedPage']) == null ? [] : JSON.parse(data['value'][0]['RecentlyVisitedPage']);
              const filteredList = _.filter(resultData, ['shortName', pageName]);
              if (filteredList.length > 0) {
                /* To remove an item from a list by looping */
                _.remove(resultData, function(n: any) {
                  return n.shortName == filteredList[0].shortName;
                });

                resultData.push({ shortName: pageName, url: pageUrl });
              } else {
                if (resultData.length >= environment.recentlyPageCount) {
                  /* To remove a particular item from a list using index */
                  resultData.splice(0, 1);
                }
                resultData.push({ shortName: pageName, url: pageUrl });
              }
              body = {
                __metadata: { type: 'SP.Data.UserBasedContentListItem' },
                Title: this.getUserInfo().profile.name,
                UserId: this.getUserName,
                RecentlyVisitedPage: JSON.stringify(resultData)
              };
              return ['Update', body, userId];
            } else {
              const RecentlyVisitedPageData = [];
              RecentlyVisitedPageData.push({ shortName: pageName, url: pageUrl });
              body = {
                __metadata: { type: 'SP.Data.UserBasedContentListItem' },
                Title: this.getUserInfo().profile.name,
                UserId: this.getUserName,
                RecentlyVisitedPage: JSON.stringify(RecentlyVisitedPageData)
              };
              return ['Post', body];
            }
          })
        );
      });
    } catch (error) {
      console.log('Error Message', error);
    }
  }
}
