import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { WebService } from './web.service';

@Injectable({
  providedIn: 'root'
})
export class RoleGuard implements CanActivate {
  constructor(private webService: WebService, private router: Router) {}

  canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    /* Return true when the user is authenticated */
    if (this.webService.authenticate) {
      if (localStorage.getItem('guestUserProfilesList') == this.webService.getUserName) {
        if (sessionStorage.getItem('redirectUri') == state.url) {
          window.alert('Access Denied...!');
          this.router.navigateByUrl('/');
        } else {
          window.alert('Access Denied...!');
        }
        return false;
      } else {
        return true;
      }
    }
    return false;
  }
}
