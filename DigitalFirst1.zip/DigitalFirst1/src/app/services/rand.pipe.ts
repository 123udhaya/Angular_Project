import { Pipe, PipeTransform } from '@angular/core';

@Pipe({ name: 'rand' })
export class RandPipe implements PipeTransform {
    transform(arr: Array<Object>, count: number) {
        if (arr == undefined) {
            return;
        }
        const len = arr.length;
        const lookup = {};
        const tmp = [];

        if (count > len) {
            count = len;
        }

        for (let i = 0; i < count; i++) {
            let index;
            do {
                index = Math.floor(Math.random() * len);
            } while (index in lookup);
            lookup[index] = null;
            tmp.push(arr[index]);
        }
        return tmp;
    }
}
